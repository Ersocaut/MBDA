--Acciones OK
DELETE FROM musician WHERE m_no = 1;