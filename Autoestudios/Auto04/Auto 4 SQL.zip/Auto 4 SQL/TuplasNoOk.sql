--No OK Atributos
INSERT INTO musician VALUES(100,'Freddie Mercury',TO_DATE('1991/10/24','YYYY/MM/DD'), TO_DATE('1946/09/05','YYYY/MM/DD'),3,5);
INSERT INTO composer VALUES(3,5,'Trap');
INSERT INTO composer VALUES(4,6,'desconocido');