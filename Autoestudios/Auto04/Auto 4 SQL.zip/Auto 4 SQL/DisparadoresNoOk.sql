--No ok
--Composicion maxima NoOk
--No permite agregar las ultimas por el trigger definido
insert into performer values (5, 5, 'violin', 'classical');
insert into performer values (6, 5, 'viola', 'jazz');
insert into performer values (7, 5, 'banjo', 'jazz');
insert into performer values (8, 5, 'sax', 'jazz');


insert into composer values (1, 5, 'jazz');
insert into composer values (2, 5, 'clasical');
insert into composer values (3, 5, 'clasical');