--Acciones de referencia
ALTER TABLE band DROP CONSTRAINT FK_band_contact;
ALTER TABLE band ADD CONSTRAINT FK_band_contact
	FOREIGN KEY(band_contact) 
		REFERENCES musician(m_no) ON DELETE CASCADE;

ALTER TABLE performer DROP CONSTRAINT FK_perf_is;
ALTER TABLE performer ADD CONSTRAINT FK_perf_is
	FOREIGN KEY(perf_is) 
		REFERENCES musician(m_no) ON DELETE CASCADE;

ALTER TABLE performance DROP CONSTRAINT FK_conducted_by;
ALTER TABLE performance ADD CONSTRAINT FK_conducted_by  
	FOREIGN KEY(conducted_by)
		REFERENCES musician(m_no) ON DELETE CASCADE;
