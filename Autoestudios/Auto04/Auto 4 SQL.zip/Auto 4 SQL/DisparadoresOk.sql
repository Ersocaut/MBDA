--Consecutivo musico
insert into place (place_no, place_town, place_country) values (1, 'L�louma', 'Guinea');
insert into place (place_no, place_town, place_country) values (2, 'Portarlington', 'Ireland');
insert into place (place_no, place_town, place_country) values (3, 'Shijiazhuang', 'China');

INSERT INTO musician (m_name,born,died,born_in,living_in) VALUES ('All','11-JAN-2000',null,1,2);
INSERT INTO musician (m_no,m_name,born,died,born_in,living_in) VALUES (42,'Pedro','20-FEB-2011',null,2,3);

--Ciudad por omisi�n
INSERT INTO musician (m_name,born,died,born_in) VALUES ('All','11-JAN-2000',null,1);
INSERT INTO musician (m_no,m_name,born,died,born_in,living_in) VALUES (43,'Pedro','20-FEB-2011',null,2,NULL);


--Composicion maxima
insert into performer values (1, 4, 'violin', 'classical');
insert into performer values (2, 4, 'viola', 'jazz');
insert into performer values (3, 4, 'banjo', 'jazz');


insert into composer values (1, 1, 'clasical');
insert into composer values (2, 3, 'clasical');
insert into composer values (3, 2, 'clasical');


--Suponer el tipo de musica
INSERT INTO composer (comp_no,comp_is) VALUES (1,2);
INSERT INTO composer (comp_no,comp_is) VALUES (2,3);

--Borrar musician en cascade
DELETE FROM musician WHERE m_no= 1;

--Modificar living_in y date_die
UPDATE musician SET living_in= 3 WHERE m_no= 2;
UPDATE musician SET died= '02-JAN-2019' WHERE m_no= 3;




