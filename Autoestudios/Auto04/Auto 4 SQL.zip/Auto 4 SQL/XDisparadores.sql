DROP TRIGGER TR_Conse_Music;
DROP TR_ciudad_default;
DROP TR_ComponeMax;
DROP TR_TipoMusic;
DROP TR_BorrarMusician;
DROP TR_ActualizarMusician;
