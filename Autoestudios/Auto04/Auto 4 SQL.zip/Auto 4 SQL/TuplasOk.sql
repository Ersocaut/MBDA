--Ok Tuplas
INSERT INTO musician VALUES(100,'Freddie Mercury',TO_DATE('1946/09/05','YYYY/MM/DD'),TO_DATE('1991/10/24','YYYY/MM/DD'),3,5);
INSERT INTO musician VALUES(101,'Elvis Presley',TO_DATE('1935/01/08','YYYY/MM/DD'),TO_DATE('1977/08/16','YYYY/MM/DD'),2,null);
INSERT INTO composer VALUES(1,3,'jazz');
INSERT INTO composer VALUES(2,4,'classical');